from . import mymodule, utils
__all__ = [mymodule, utils]
__version__ = '0.1.0'  # version number here