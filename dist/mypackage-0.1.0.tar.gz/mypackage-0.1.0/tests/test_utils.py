from mypackage.utils import printStackTrace
import psycopg2

def test_printStackTrace():
    conn_postgresql = None
    try:
        conn_postgresql = psycopg2.connect(database="abc123", user="abc123", password="abc123", host="127.0.0.1",
                                           port="5432")
        print("Database opened successfully")

        cur = conn_postgresql.cursor()
        cur.execute("SELECT fname || ' ' || lname as StudentName, cid as ClassId from students")
        rows = cur.fetchall()

        for row in rows:
            print("StudentName =", row[0])
            print("ClassId =", row[1], "\n")

    except Exception:
        '''
        Printing stack trace
        '''
        printStackTrace('Error connecting postgres database')
        import sys
        sys.exit(-1)

    if conn_postgresql:
        conn_postgresql.close()

    assert hello_world() == "Hello, world!"
